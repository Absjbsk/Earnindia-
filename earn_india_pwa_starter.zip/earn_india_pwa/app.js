let language = "hi";
const toast = (message) => { const el=document.getElementById("toast"); el.textContent=message; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),2200); };
function setLanguage(next){ language=next; document.documentElement.lang=next; document.querySelectorAll("[data-hi][data-en]").forEach(el=>el.textContent=el.dataset[next]); document.getElementById("langBtn").textContent=next==="hi"?"English":"हिंदी"; }
document.getElementById("langBtn").addEventListener("click",()=>setLanguage(language==="hi"?"en":"hi"));
document.getElementById("year").textContent=new Date().getFullYear();
document.querySelectorAll("[data-offer]").forEach(btn=>btn.addEventListener("click",async()=>{const sample=`https://example.com/${btn.dataset.offer}?ref=EARNINDIA`;try{await navigator.clipboard.writeText(sample);toast(language==="hi"?"डेमो लिंक कॉपी हुआ":"Demo link copied");}catch{toast(sample);}}));
document.getElementById("copyRef").addEventListener("click",async()=>{const value=document.getElementById("refLink").value;try{await navigator.clipboard.writeText(value);toast(language==="hi"?"लिंक कॉपी हुआ":"Link copied");}catch{toast(value);}});
let installPrompt;
const installBtn=document.getElementById("installBtn");
window.addEventListener("beforeinstallprompt",event=>{event.preventDefault();installPrompt=event;installBtn.hidden=false;});
installBtn.addEventListener("click",async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;installBtn.hidden=true;});
if("serviceWorker" in navigator && location.protocol.startsWith("http")){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}
